# Giai đoạn A — hồ sơ khảo sát nguồn HCMUS

**Ngày lập hồ sơ:** 15/10/2026 (Asia/Ho_Chi_Minh)

## Cách đọc trạng thái

- **Đã xác minh qua trang công khai/index:** URL và cấu trúc được thấy trong kết quả trang web có thể truy cập công khai.
- **Chưa live-probe:** chưa chạy GET trực tiếp từ môi trường phát triển này. Không suy diễn endpoint RSS/API chỉ từ tên công nghệ.
- **Cần xác minh bằng máy người dùng:** chạy `python -m hcmus_hub audit` trong mạng của mèo để lấy HTTP status/Content-Type và kiểm tra cấu trúc phản hồi.

## Danh mục nguồn

| ID | Nguồn | URL danh mục / trang khởi đầu | Dạng dữ liệu quan sát được | Hướng lấy đề xuất | Trạng thái |
|---|---|---|---|---|---|
| `fit` | FIT | `https://www.fit.hcmus.edu.vn/beta/tin-tuc/c/thong-bao-chung` | Danh mục phân trang, tiêu đề, trích đoạn, ngày đăng; bài chi tiết theo `/beta/tin-tuc/d/<slug>`; tệp đính kèm được liệt kê cuối bài | HTML là đường fallback; kiểm tra feed/API trước; dùng selector URL `/tin-tuc/d/` | Cấu trúc nội dung đã thấy; endpoint chưa live-probe |
| `ctsv` | Phòng Công tác Sinh viên | `https://ctsv.hcmus.edu.vn/` | Bài chi tiết công khai theo `/news/<slug>` | Kiểm tra feed/API; đọc trang chủ/danh mục rồi lấy bài chi tiết | Mẫu bài công khai đã thấy; trang danh sách cần audit |
| `hcmus` | Website chính | `https://hcmus.edu.vn/` | Nhiều danh mục/đơn vị và đường dẫn chức năng; không nên chỉ dựa vào trang chủ | Tìm sitemap/feed/API, rồi liệt kê danh mục sinh viên; kiểm tra selector theo mẫu HTML thật | Chưa live-probe |
| `pdt` | Phòng Đào tạo | `https://hcmus.edu.vn/phong-dao-tao/` | Các khối tin dành cho Tân sinh viên/Đại học/Cao đẳng; danh sách thông báo học vụ, bài viết chi tiết và tệp liên quan | HTML/API tùy kết quả audit; ưu tiên cao do liên quan học vụ | Trang thông tin công khai đã thấy; selector cần kiểm thử |
| `tuyensinh` | Cổng tuyển sinh | `https://tuyensinh.hcmus.edu.vn/` | Tin tuyển sinh và các trang thông tin theo năm/từng chủ đề | HTML/API tùy audit; lọc theo độ liên quan tới sinh viên hiện tại | Chưa live-probe |
| `svnckh` | Website NCKH sinh viên | `https://svnckhcn.hcmus.edu.vn/danh-muc/thong-bao-tin-tuc/` | Danh mục thông báo, bài chi tiết theo slug; site hiển thị các danh mục Thông báo/Tin tức/Nộp hồ sơ | HTML; thử RSS/API; tránh mặc định endpoint WordPress tồn tại | Cấu trúc danh mục/bài đã thấy; endpoint chưa live-probe |
| `doantn` | Đoàn trường - Hội Sinh viên | `https://doantn.hcmus.edu.vn/` và `https://doantn.hcmus.edu.vn/niem-yet-hoat-dong/` | Tin mới, hoạt động Đoàn–Hội, nội dung niêm yết theo đơn vị/khoa | HTML/API tùy audit; giới hạn tải tệp đính kèm, không tải danh sách cá nhân hàng loạt | Trang và bài công khai đã thấy; selector cần kiểm thử |
| `stsv` | Sổ tay Sinh viên | `https://stsv.hcmus.edu.vn/` | Kho tra cứu học vụ, quy chế, học bổng, điểm rèn luyện; có mục “Mới cập nhật” | Theo dõi nội dung thay đổi như reference data, không mặc định coi mọi trang là thông báo mới | Nguồn công khai đã thấy; đang tắt mặc định |
| `research` | Cổng nghiên cứu HCMUS | `https://research.hcmus.edu.vn/` | Thiên về thông tin/thống kê công bố khoa học | Theo dõi định kỳ thưa hơn; chỉ bật nếu xác định use case | Đang tắt mặc định, cần xác minh trường dữ liệu |

## Những cấu trúc đã xác minh được

### FIT

Trang danh mục công khai đã cho thấy nhiều nhóm riêng: Thông báo chung, Học bổng, Hoạt động sinh viên, Thông báo chương trình chuẩn, Thông báo hệ hoàn chỉnh, Hội thảo–Hội nghị, Tuyển dụng và Tốt nghiệp. Danh mục thông báo chung có phân trang với tham số `p`, ví dụ trang tiếp theo dùng `?p=2`. Bài chi tiết có URL dạng `/beta/tin-tuc/d/<slug>`, chứa ngày đăng, thân bài, thời hạn và đôi khi tệp đính kèm. Vì vậy parser FIT trong prototype chọn các anchor có đường dẫn `/tin-tuc/d/`, rồi vào bài chi tiết lấy nội dung.

Danh mục FIT đang được đưa vào cấu hình:

- `/beta/tin-tuc/c/thong-bao-chung`
- `/beta/tin-tuc/c/thong-tin-hoc-bong`
- `/beta/tin-tuc/c/hoat-dong-sinh-vien`
- `/beta/tin-tuc/c/thong-bao-he-chinh-quy`
- `/beta/tin-tuc/c/thong-bao-he-hoan-chinh`
- `/beta/tin-tuc/c/hoi-thao-hoi-nghi`
- `/beta/tin-tuc/c/thong-tin-tuyen-dung`
- `/beta/tin-tuc/c/tot-nghiep-qui-trinh-thuc-hien`

Một số đường dẫn tương tự không có `/beta` cũng xuất hiện trên website hiện hành. Prototype hiện dùng các đường dẫn beta đã quan sát được trong danh mục; không gộp alias chưa kiểm thử vào cấu hình chính để tránh lấy trùng/nhiễu.

### Phòng Đào tạo

Trang Phòng Đào tạo có các khối thông báo riêng theo nhóm người học (ví dụ Tân sinh viên, Đại học, Cao đẳng). Nên coi đây là nguồn độc lập, vì nếu chỉ đọc trang chủ HCMUS có thể bỏ sót các thông báo học vụ quan trọng.

### Đoàn–Hội và SVNCKH

Website `doantn.hcmus.edu.vn` đăng tin hoạt động của Đoàn trường, Hội Sinh viên và các đơn vị; `svnckhcn.hcmus.edu.vn` có danh mục thông báo NCKH riêng. Đây là hai đầu mối cần đưa vào bản đầu bên cạnh FIT và CTSV.

### Sổ tay Sinh viên và research

Sổ tay là kho tra cứu có mục “Mới cập nhật”, nên hướng xử lý tốt nhất là theo dõi thay đổi trên một danh sách các URL quan trọng, thay vì kéo toàn bộ chương/mục vào luồng thông báo. Cổng nghiên cứu có nội dung thống kê công bố; tần suất kiểm tra thấp hơn là phù hợp.

## Các giả thuyết kỹ thuật chưa được xác nhận

- RSS/Atom có tồn tại và hoạt động trên từng host hay không.
- Các host có sitemap tổng hoặc sitemap theo loại bài hay không.
- Các endpoint `/wp-json/wp/v2/posts` hoặc feed kiểu WordPress có trả về API hợp lệ hay chỉ redirect/404.
- Trang chủ CTSV/HCMUS/Tuyển sinh có render danh sách bài ngay trong HTML hay cần JavaScript.
- Selector CSS tối ưu, cách phân trang và trường ngày đăng chính xác trên mọi nguồn.
- Có API công khai được hỗ trợ chính thức cho Portal Sinh viên hoặc UStudy không. Phần này cần khảo sát riêng qua phiên đăng nhập hợp lệ, không đưa credentials vào prototype.

## Audit trực tiếp tại máy người dùng

Chạy:

```bash
python -m hcmus_hub audit --source fit --output data/audit
python -m hcmus_hub audit --output data/audit
```

Mở `data/audit/source-audit.md`. Đây mới là nơi có HTTP status, Content-Type và phân loại phản hồi từ mạng thực tế của máy mèo. Gửi lại báo cáo này (sau khi rà soát không có token/cookie) để tinh chỉnh parser.

## Rủi ro và phương án xử lý

1. **Bài trùng giữa các đơn vị:** dùng fingerprint tiêu đề + ngày; gắn nhiều nguồn vào một bản tin.
2. **Bài sửa/gia hạn:** lưu content hash và revision khi nội dung đổi.
3. **HTML đổi cấu trúc:** nguồn có status lỗi hoặc zero items phải nổi bật trong log; có fixture tests để phát hiện lỗi logic cơ bản.
4. **PDF/tệp danh sách:** bản đầu chỉ giữ đường dẫn đính kèm, không tự tải hàng loạt tệp.
5. **Nguồn cần đăng nhập:** tách module riêng; chỉ đọc dữ liệu tài khoản được phép và tránh lưu bí mật.
6. **Tải gây ảnh hưởng server:** robots check, timeout, retry giới hạn, response cap và delay giữa request; không chạy đồng thời bừa bãi.


## Cập nhật bằng audit trực tiếp từ máy người dùng — 15/10/2026 23:19 +07:00

Nguồn: file `source-audit.md` do người dùng chạy và gửi lại. Đây là HTTP probe thực tế từ máy người dùng, khác với phần khảo sát qua trang công khai ở trên.

| Nguồn | Kết quả đã quan sát | Cách cấu hình trong v0.2 | Điều còn phải kiểm thử |
|---|---|---|---|
| FIT | Tám danh mục trả HTTP 200 HTML; các feed phổ biến và WordPress REST API thử nghiệm trả 404 | Giữ HTML danh mục và selector liên kết `/beta/tin-tuc/d/` | `sync` phải lấy đúng bài, phân trang, ngày và tệp |
| CTSV | `robots.txt` 200; `sitemap.xml` 200 XML `urlset`; trang chủ 200 HTML nhưng audit đếm 0 anchor | Đọc sitemap, chỉ nhận URL có `/news/`, rồi làm giàu từ bài chi tiết | Rerun audit v0.2 để ghi số URL; chạy sync để xác nhận sitemap chứa các bài tin |
| HCMUS | `/rss.xml` 200 XML `rss`; `/wp-json/wp/v2/posts?per_page=1` trả JSON danh sách; `/feed/` và `/feed` trả HTML chứ không phải RSS | Ưu tiên `/rss.xml`, giữ trang chủ và trang CTSV trên website trường làm bổ sung HTML | Kiểm tra RSS có đủ tin cần theo dõi, tránh bài trùng giữa feed và HTML |
| Phòng Đào tạo | Trang `/phong-dao-tao/` 200 HTML; endpoint RSS phổ biến cùng REST API trên domain HCMUS hoạt động ở mức probe chung | Dùng trang `/phong-dao-tao/` qua HTML | Cần kiểm tra selector bài tin thực tế; API WordPress chung chưa chứng minh là feed riêng cho Phòng Đào tạo |
| Tuyển sinh | `/feed/` 200 XML `rss`; REST API WordPress trả JSON danh sách | Feed trước, trang chủ HTML làm bổ sung | Kiểm tra số tin, link chi tiết và mức độ phù hợp với sinh viên hiện tại |
| SVNCKH | Feed chung và hai feed danh mục trả XML `rss`; REST API trả JSON danh sách | RSS riêng cho danh mục thông báo và tin tức | Kiểm tra nội dung feed, ngày đăng và tệp liên kết |
| Đoàn trường | `/feed/`, `/news/feed/` trả XML `rss`; REST API trả JSON; trang niêm yết hoạt động 200 HTML | Kết hợp `/news/feed/`, `/feed/` và trang niêm yết HTML | Kiểm tra bản ghi trùng và hoạt động có bị bỏ sót không |
| Sổ tay Sinh viên | Trang chủ 200 HTML, feed/sitemap/API thử nghiệm phổ biến 404; `robots.txt` 200 | Giữ tắt mặc định, xem như kho tra cứu | Cần tìm cấu trúc mục “Mới cập nhật” nếu muốn theo dõi sửa đổi |
| Cổng nghiên cứu | Trang chủ 200 HTML; các endpoint phổ biến thử nghiệm trả 404 | Giữ tắt mặc định | Cần xác định trang dữ liệu cụ thể có ích trước khi tạo bộ thu thập |

**Chú ý:** HTTP 404 ở một endpoint phổ biến chỉ có nghĩa URL thử nghiệm đó không tồn tại/không được cung cấp; không chứng minh website không có API khác. HTTP 200 cũng chưa đảm bảo phản hồi là loại dữ liệu mong muốn — ví dụ `/feed/` trên `hcmus.edu.vn` trả HTML, nên v0.2 không dùng endpoint đó làm RSS.
