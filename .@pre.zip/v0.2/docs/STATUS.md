# Trạng thái bàn giao — 15/10/2026 (v0.2)

## Đã làm

- Tạo `config/sources.json` với 9 nguồn: FIT, CTSV, HCMUS, Phòng Đào tạo, Tuyển sinh, SVNCKH, Đoàn–Hội, Sổ tay Sinh viên và cổng nghiên cứu.
- Bật mặc định 7 nguồn tin tức/thông báo; tắt mặc định Sổ tay và Research vì đây là nguồn tra cứu/reference cần cách xử lý khác.
- Thêm lệnh audit để kiểm tra robots.txt, sitemap, feed RSS/Atom, endpoint WordPress REST phổ biến và URL danh mục; báo cáo ra Markdown + JSON.
- Thêm bộ lấy HTTP có timeout, retry giới hạn, giới hạn kích thước phản hồi, độ trễ theo host và kiểm tra robots.txt.
- Thêm parser RSS/Atom, HTML và sitemap URL-set; trích xuất title/date/snippet/body/URL tệp đính kèm, phân trang cho đường dẫn FIT đã quan sát.
- Cập nhật cấu hình theo audit do người dùng chạy: HCMUS RSS tại `/rss.xml`; Tuyển sinh `/feed/`; SVNCKH RSS theo danh mục; Đoàn trường `/feed/` và `/news/feed/`; CTSV thử phát hiện bài `/news/` từ `sitemap.xml`.
- Thêm SQLite với nguồn gốc nhiều nguồn, khử trùng lặp heuristic, dấu vết nội dung và lưu revision khi bài đã có thân nội dung thay đổi.
- Thêm CLI `audit`, `sync`, `list`, `export` và hướng dẫn chạy trên Kali/Ubuntu/Windows.
- Có 18 kiểm thử tự động cho parser HTML/RSS/sitemap, phân trang, cơ sở dữ liệu, khử trùng lặp và đồng bộ giả lập.

## Kết quả kiểm thử trong môi trường phát triển

- `python -m unittest discover -v`: **18 tests passed**.
- `python -m compileall -q hcmus_hub tests`: thành công.
- `python -m hcmus_hub --help`: lệnh CLI khởi động được.
- Đã kiểm tra JSON cấu hình và xác nhận có 9 nguồn, trong đó 7 nguồn bật mặc định.

## Chưa thể tuyên bố hoàn tất

- Báo cáo audit trực tiếp từ máy người dùng đã cung cấp bằng chứng endpoint cho 9 nguồn; kết quả được tóm tắt trong `AUDIT_RESULTS_2026-10-15.md`. Môi trường phát triển của trợ lý vẫn không có DNS/Internet để tự chạy đồng bộ production end-to-end.
- Các endpoint feed được đánh dấu dùng trong config là dựa trên audit của người dùng, nhưng parser nội dung bài và tệp đính kèm vẫn cần xác nhận bằng lần `sync` thật.
- FIT vẫn dùng HTML. CTSV thử chiến lược sitemap do homepage trả 0 liên kết trong audit; cần xác nhận sitemap có bao nhiêu URL `/news/` và các bài chi tiết có được trích xuất đúng. Các selector HTML bổ sung vẫn cần tinh chỉnh bằng output `sync` thật.
- Chưa dựng giao diện web (đó là giai đoạn C), chưa chạy scheduler 08:00, chưa triển khai hosting, chưa kết nối Portal Sinh viên/UStudy.

## Tiêu chí trước khi tin dùng dữ liệu

Không coi bộ thu thập là ổn định cho đến khi audit từ máy thật xác nhận endpoint, sync ra các bài có tiêu đề/ngày/link đúng, chạy lần hai không tăng số bài trùng, và một thông báo có sửa nội dung tạo revision hợp lý.
