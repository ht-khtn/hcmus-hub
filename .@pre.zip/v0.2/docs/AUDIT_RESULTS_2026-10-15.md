# Kết quả audit nguồn HCMUS Hub — 15/10/2026

Báo cáo này tóm tắt `source-audit.md` người dùng tạo lúc 23:19:16 +07:00. Nó ghi lại kết quả probe, không phải cam kết rằng nội dung đã được đồng bộ và kiểm tra ngữ nghĩa thành công.

## Feed/API đã được xác nhận ở mức endpoint

- **HCMUS:** `https://hcmus.edu.vn/rss.xml` trả XML root `rss`. `https://hcmus.edu.vn/wp-json/wp/v2/posts?per_page=1` trả JSON dạng danh sách. Hai URL `/feed/` và `/feed` trả HTML nên không được dùng làm feed.
- **Tuyển sinh:** `https://tuyensinh.hcmus.edu.vn/feed/` trả XML root `rss`; WordPress REST API thử nghiệm trả JSON dạng danh sách.
- **SVNCKH:** `/feed/`, `/danh-muc/thong-bao-tin-tuc/feed/` và `/danh-muc/tin-tuc/feed/` trả RSS; REST API thử nghiệm trả JSON dạng danh sách.
- **Đoàn trường:** `/feed/` và `/news/feed/` trả RSS; REST API thử nghiệm trả JSON dạng danh sách.
- **CTSV:** `https://ctsv.hcmus.edu.vn/sitemap.xml` trả XML root `urlset`; homepage trả HTML nhưng report ghi 0 anchor. v0.2 thêm parser URL-set và chỉ nhận URL trong đường dẫn `/news/`. Số URL thực tế chưa được ghi trong báo cáo v0.1, vì vậy cần chạy audit v0.2 lại.
- **FIT:** các feed/API phổ biến đã thử trả 404; tám trang danh mục trả HTML 200, nên giữ HTML parser.
- **Phòng Đào tạo:** trang `/phong-dao-tao/` trả HTML 200. API/feed chung trên domain HCMUS hoạt động ở mức probe, nhưng chưa chứng minh một endpoint riêng cho Phòng Đào tạo.
- **Sổ tay Sinh viên** và **research.hcmus.edu.vn:** homepage trả HTML 200; các đường dẫn feed/sitemap/API phổ biến được thử đều trả 404. Giữ tắt mặc định, không có nghĩa toàn website không có endpoint khác.

## Thay đổi trong v0.2

1. Thêm `mode=feed|html|sitemap|auto` theo từng listing.
2. Thêm parser sitemap URL-set, lọc URL theo host và path, dùng `lastmod` để ưu tiên URL mới hơn. `lastmod` được coi là gợi ý sửa đổi, không khẳng định ngày xuất bản.
3. Cập nhật cấu hình dùng RSS đã xác nhận cho HCMUS, Tuyển sinh, SVNCKH và Đoàn trường.
4. Với CTSV, dùng sitemap làm đầu vào thay vì homepage không có anchor trong kết quả audit.
5. Mở rộng audit để ghi số mục RSS và số URL trong sitemap cùng vài URL mẫu.

## Kiểm thử

`python -m unittest discover -v`: 18/18 test qua trong môi trường phát triển. Các kiểm thử dùng fixture/fake fetcher, không thay thế cho lần đồng bộ HTTP trực tiếp từ máy người dùng.

## Các bước kiểm chứng tiếp theo

```bash
python -m hcmus_hub audit --source ctsv --output data/audit
python -m hcmus_hub sync --source ctsv --delay 1.0
python -m hcmus_hub list --limit 30
```

Sau đó kiểm tra các nguồn feed đã xác nhận:

```bash
python -m hcmus_hub sync --source hcmus --source tuyensinh --source svnckh --source doantn --delay 1.0
python -m hcmus_hub list --limit 50
```
