import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from hcmus_hub.models import ListingConfig, SourceConfig
from hcmus_hub.store import Store
from hcmus_hub.sync import sync_source

ROOT = Path(__file__).resolve().parent


class FakeFetcher:
    warnings = []

    async def get(self, url, **kwargs):
        if "/beta/tin-tuc/c/" in url:
            body = (ROOT / "fixtures" / "fit_listing.html").read_text(encoding="utf-8")
        elif url.endswith("dang-ky-tham-quan-bosch"):
            body = (ROOT / "fixtures" / "fit_detail.html").read_text(encoding="utf-8")
        else:
            body = (ROOT / "fixtures" / "fit_detail.html").read_text(encoding="utf-8")
        return SimpleNamespace(url=url, status_code=200, content_type="text/html; charset=utf-8", text=body, headers={})


class SyncTests(unittest.TestCase):
    def test_sync_can_use_sitemap_as_listing(self):
        class SitemapFetcher:
            warnings = []

            async def get(self, url, **kwargs):
                if url.endswith("sitemap.xml"):
                    body = """<?xml version=\"1.0\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"><url><loc>https://ctsv.hcmus.edu.vn/news/thong-bao-moi</loc><lastmod>2026-10-14</lastmod></url></urlset>"""
                    ctype = "application/xml"
                else:
                    body = (ROOT / "fixtures" / "fit_detail.html").read_text(encoding="utf-8")
                    ctype = "text/html; charset=utf-8"
                return SimpleNamespace(url=url, status_code=200, content_type=ctype, text=body, headers={})

        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "hcmus.sqlite3")
            source = SourceConfig(
                id="ctsv", name="CTSV", owner="CTSV", base_url="https://ctsv.hcmus.edu.vn/",
                kind="announcements", enabled=True,
                listings=[ListingConfig(
                    "https://ctsv.hcmus.edu.vn/sitemap.xml", "Thông báo CTSV", [],
                    mode="sitemap", link_patterns=["/news/"]
                )],
                max_pages=1, max_details_per_sync=1,
            )
            try:
                report = asyncio.run(sync_source(source, SitemapFetcher(), store, max_details=0))
                self.assertEqual(report["articles_discovered"], 1)
                rows = store.list_articles(limit=10)
                self.assertEqual(rows[0]["source_urls"], "https://ctsv.hcmus.edu.vn/news/thong-bao-moi")
            finally:
                store.close()

    def test_sync_listing_detail_and_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "hcmus.sqlite3")
            source = SourceConfig(
                id="fit", name="FIT", owner="FIT", base_url="https://www.fit.hcmus.edu.vn/",
                kind="announcements", enabled=True,
                listings=[ListingConfig(
                    "https://www.fit.hcmus.edu.vn/beta/tin-tuc/c/thong-bao-chung",
                    "Thông báo chung", ["a[href*='/beta/tin-tuc/d/']"]
                )],
                max_pages=1, max_details_per_sync=1,
            )
            try:
                report = asyncio.run(sync_source(source, FakeFetcher(), store, max_details=1))
                self.assertEqual(report["articles_discovered"], 2)
                self.assertEqual(report["details_fetched"], 1)
                self.assertEqual(store.counts()["articles"], 2)
                rows = store.list_articles(limit=10)
                detailed = next(row for row in rows if "Bosch" in row["title"])
                self.assertIn("Thời hạn đăng ký", detailed["content"])
                self.assertEqual(detailed["source_count"], 1)
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()
