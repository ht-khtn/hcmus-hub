# Báo cáo audit nguồn HCMUS Hub

- Chạy lúc: `2026-10-15T23:55:37+07:00`
- File cấu hình: `D:\app\hcmus-hub\hcmus-hub-v0.2\config\sources.json`

## Phòng Công tác Sinh viên (`ctsv`)

- Base URL: https://ctsv.hcmus.edu.vn/
- Hướng đề xuất: **manual_review_or_browser**

| Loại probe | HTTP | Phân loại | URL | Ghi chú |
|---|---:|---|---|---|
| robots | 200 | robots_txt | https://ctsv.hcmus.edu.vn/robots.txt | robots.txt đọc được; 4 dòng Disallow; 1 Sitemap được khai báo. |
| sitemap | 200 | sitemap | https://ctsv.hcmus.edu.vn/sitemap.xml | XML hợp lệ, root=urlset; 460 URL. Ví dụ: https://ctsv.hcmus.edu.vn/; https://ctsv.hcmus.edu.vn/about; https://ctsv.hcmus.edu.vn/info |
| sitemap_index | 404 | not_found | https://ctsv.hcmus.edu.vn/sitemap_index.xml | HTTP 404. |
| wordpress_sitemap | 404 | not_found | https://ctsv.hcmus.edu.vn/wp-sitemap.xml | HTTP 404. |
| rss_feed | 404 | not_found | https://ctsv.hcmus.edu.vn/feed/ | HTTP 404. |
| rss_feed | 404 | not_found | https://ctsv.hcmus.edu.vn/news/feed/ | HTTP 404. |
| rss_feed | 404 | not_found | https://ctsv.hcmus.edu.vn/feed | HTTP 404. |
| rss_feed | 404 | not_found | https://ctsv.hcmus.edu.vn/rss.xml | HTTP 404. |
| atom_feed | 404 | not_found | https://ctsv.hcmus.edu.vn/atom.xml | HTTP 404. |
| wordpress_api | 404 | not_found | https://ctsv.hcmus.edu.vn/wp-json/wp/v2/posts?per_page=1 | HTTP 404. |
