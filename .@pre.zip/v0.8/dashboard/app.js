(() => {
  const $ = (sel) => document.querySelector(sel);
  const state = { mode: 'all', source: '', category: '', q: '', page: 1, pages: 1, total: 0, selectedId: null, selected: null, stats: null, sources: [] };
  let searchTimer = null;
  let toastTimer = null;

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const short = (value, max=130) => { const s = String(value || '').replace(/\s+/g, ' ').trim(); return s.length > max ? s.slice(0, max - 1) + '…' : s; };
  const fmtDate = (value) => {
    if (!value) return 'Chưa rõ ngày đăng';
    const d = new Date(value + 'T00:00:00');
    return Number.isNaN(d.getTime()) ? value : new Intl.DateTimeFormat('vi-VN', {day:'2-digit',month:'2-digit',year:'numeric'}).format(d);
  };
  const dateIsUncertain = (a) => !!a.published_at && ['legacy_unverified','unknown',''].includes(a.published_at_source || '');
  const sourceNames = (a) => (a.source_names || '').split(',').map(x => x.trim()).filter(Boolean);
  const firstSource = (a) => sourceNames(a)[0] || 'Nguồn chưa rõ';
  const toast = (msg) => { const el=$('#toast'); el.textContent=msg; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2600); };
  async function api(url, options={}) {
    const response = await fetch(url, { headers: {'Content-Type':'application/json'}, ...options });
    const payload = await response.json().catch(()=>({error:'Phản hồi không phải JSON'}));
    if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
    return payload;
  }
  function setStatus(text, ok=true) {
    $('#connection-status').textContent = text;
    const dot = document.querySelector('.sidebar-footer .status-dot');
    if (dot) dot.style.background = ok ? '#3fa77b' : '#c46a4d';
  }
  async function loadStats() {
    state.stats = await api('/api/stats');
    $('#stat-total').textContent = state.stats.articles.toLocaleString('vi-VN');
    $('#stat-unread').textContent = state.stats.unread.toLocaleString('vi-VN');
    $('#stat-favorites').textContent = state.stats.favorites.toLocaleString('vi-VN');
    $('#stat-review').textContent = state.stats.needs_review.toLocaleString('vi-VN');
    $('#nav-total').textContent = state.stats.articles;
    $('#nav-unread').textContent = state.stats.unread;
    $('#nav-favorites').textContent = state.stats.favorites;
    $('#nav-review').textContent = state.stats.needs_review;
    $('#mark-all-read').disabled = state.stats.unread === 0;
    state.sources = state.stats.sources || [];
    const options = ['<option value="">Tất cả nguồn</option>', ...state.sources.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`)].join('');
    $('#source-filter').innerHTML = options;
    $('#source-list').innerHTML = state.sources.map(s=>`<button class="source-shortcut ${state.source===s.id?'active':''}" data-source="${esc(s.id)}"><span class="mini-dot"></span><span>${esc(s.name)}</span><span class="source-n">${s.articles}</span></button>`).join('');
    setStatus(`${state.sources.length} nguồn · CSDL cục bộ`, true);
  }
  function buildCategories(items) {
    const previous = state.category;
    const set = new Set((state.stats?.categories || []).filter(Boolean));
    // Keep a fallback for databases whose categories are not represented in the stats response.
    items.forEach(a => (a.source_categories || '').split(',').map(s=>s.trim()).filter(Boolean).forEach(x=>set.add(x)));
    const opts = ['<option value="">Mọi danh mục</option>', ...Array.from(set).sort((a,b)=>a.localeCompare(b,'vi')).map(c=>`<option value="${esc(c)}">${esc(c)}</option>`)].join('');
    $('#sort-category').innerHTML = opts;
    if (set.has(previous)) $('#sort-category').value=previous;
    else state.category='';
  }
  function dateMarkup(a) {
    const uncertain = dateIsUncertain(a);
    return `<span class="date-conf"><span class="confidence-dot ${(!a.published_at || uncertain)?'unknown':''}"></span>${esc(fmtDate(a.published_at))}${uncertain?' · chưa xác minh':''}</span>`;
  }
  function renderList(payload) {
    state.total = payload.total; state.pages=payload.pages;
    $('#feed-subcount').textContent = `· ${payload.total.toLocaleString('vi-VN')} bài`;
    $('#page-label').textContent = payload.total ? `${payload.page}/${payload.pages}` : '';
    $('#pagination-label').textContent = `Trang ${payload.page} / ${payload.pages}`;
    $('#prev-page').disabled = payload.page <= 1;
    $('#next-page').disabled = payload.page >= payload.pages;
    const heading = ({all:'Tất cả thông báo',unread:'Thông báo chưa đọc',favorites:'Thông báo đã lưu',review:'Thông báo cần kiểm tra'})[state.mode] || 'Thông báo';
    $('#feed-heading').textContent = heading;
    if (!payload.items.length) {
      $('#feed-list').innerHTML = `<div class="empty-state"><div class="empty-icon">⌕</div><strong>Không tìm thấy thông báo</strong><span>Thử từ khóa hoặc bộ lọc khác.</span></div>`;
      state.selectedId=null; state.selected=null; renderEmptyDetail(); return;
    }
    $('#feed-list').innerHTML = payload.items.map(a=>{
      const chosen=state.selectedId===a.id;
      const categories=(a.source_categories||a.category||'Chưa phân loại').split(',').map(x=>x.trim()).filter(Boolean);
      const summary=a.summary || a.content_preview || 'Chưa có nội dung trích xuất; mở bài gốc để xem chi tiết.';
      return `<article class="article-card ${chosen?'selected ':''}${a.read_at?'':'unread'}" data-id="${a.id}" tabindex="0" role="button" aria-label="Mở thông báo ${esc(a.title)}">
        <div class="card-meta"><span class="source-chip">${esc(firstSource(a))}</span><span class="category-chip">${esc(categories[0] || 'Chưa phân loại')}</span></div>
        <h3 class="card-title">${esc(a.title)}</h3><p class="card-summary">${esc(short(summary,190))}</p>
        <div class="card-bottom">${dateMarkup(a)}<span class="card-trailing">${a.is_favorite?'★':'›'}</span></div>
      </article>`;
    }).join('');
    if (!state.selectedId || !payload.items.some(a=>a.id===state.selectedId)) {
      state.selectedId=payload.items[0].id;
      loadDetail(state.selectedId, false);
    }
  }
  function renderEmptyDetail(){ $('#detail-panel').innerHTML='<div class="detail-empty"><div class="empty-icon">⌕</div><h2>Chưa có bài để hiển thị</h2><p>Thử bỏ bớt bộ lọc hoặc tìm kiếm bằng từ khóa khác.</p></div>'; }
  async function loadList() {
    $('#feed-list').innerHTML='<div class="loading"><span class="spinner"></span>Đang đọc thông báo…</div>';
    const params=new URLSearchParams({page:String(state.page),limit:'30',mode:state.mode});
    if(state.q)params.set('q',state.q); if(state.source)params.set('source',state.source); if(state.category)params.set('category',state.category);
    try {
      const payload=await api('/api/articles?'+params.toString());
      buildCategories(payload.items); renderList(payload);
    } catch(err) { $('#feed-list').innerHTML=`<div class="empty-state"><strong>Không tải được thông báo</strong><span>${esc(err.message)}</span></div>`; setStatus('Lỗi đọc CSDL',false); }
  }
  function richHtmlHasPayload(markup) {
    if (!markup) return false;
    const template = document.createElement('template');
    template.innerHTML = markup;
    return Boolean(template.content.textContent.trim() || template.content.querySelector('a[href], img[src], table, ul, ol, dl'));
  }
  function renderDetail(a) {
    state.selected=a;
    const categories=(a.source_categories || a.category || 'Chưa phân loại').split(',').map(x=>x.trim()).filter(Boolean);
    const links=a.sources || [];
    const body=(a.content || '').trim();
    const bodyHtml=(a.content_html || '').trim();
    const hasRichPayload=Boolean(a.has_rich_payload) || richHtmlHasPayload(bodyHtml);
    const summary=(a.summary || '').trim();
    const attachments=a.attachments || [];
    const hasDisplayableBody=Boolean(body) || hasRichPayload || attachments.length > 0;
    const quality=[];
    if(!a.published_at || dateIsUncertain(a))quality.push('Ngày đăng chưa được xác minh');
    // Some official notices consist only of a link/image/table. Don't flag them
    // as missing body when the extracted rich fragment is useful.
    if(!hasDisplayableBody)quality.push('Chưa trích xuất được nội dung hoặc liên kết hữu ích');
    if(a.title && (a.title.includes('[CHƯA LẤY CHI TIẾT]') || /^Thong bao\b/i.test(a.title)))quality.push('Tiêu đề cần kiểm tra');
    $('#detail-panel').innerHTML=`<div class="detail-content">
      <div class="detail-meta"><span class="source-chip">${esc(firstSource(a))}</span>${categories.slice(0,3).map(c=>`<span class="category-chip">${esc(c)}</span>`).join('')}</div>
      <h2 class="detail-title">${esc(a.title)}</h2>
      <div class="detail-date-row"><span>▦ ${esc(fmtDate(a.published_at))}${dateIsUncertain(a)?' · chưa xác minh':''}</span><span>·</span><span>${a.read_at?'Đã đọc':'Chưa đọc'}</span>${a.source_count>1?`<span>· ${a.source_count} nguồn</span>`:''}</div>
      <div class="detail-actions"><button class="button primary" id="toggle-read">${a.read_at?'Đánh dấu chưa đọc':'Đánh dấu đã đọc'}</button><button class="button favorite ${a.is_favorite?'active':''}" id="toggle-favorite">${a.is_favorite?'★ Đã lưu':'☆ Lưu thông báo'}</button>${links[0]?`<a class="button" target="_blank" rel="noopener noreferrer" href="${esc(links[0].source_url)}">Mở bài gốc ↗</a>`:''}</div>
      ${summary?`<div class="detail-summary">${esc(summary)}</div>`:''}
      <div class="body-heading">Nội dung thông báo</div>
      ${bodyHtml && hasRichPayload ? `<div class="article-body rich-content">${bodyHtml}</div>` : body ? `<div class="article-body">${esc(body)}</div>` : `<div class="body-missing">${attachments.length ? 'Trang nguồn không cung cấp phần thân bài đọc được; tệp liên quan được liệt kê bên dưới.' : 'Trang nguồn không cung cấp phần thân bài để nhúng. Mở bài gốc bên trên để xem liên kết, biểu mẫu hoặc nội dung bổ sung.'}</div>`}
      ${attachments.length?`<div class="body-heading">Tệp đính kèm</div><div class="attachment-list">${attachments.map(u=>`<a target="_blank" rel="noopener noreferrer" href="${esc(u)}">↳ ${esc(u.split('/').pop()||u)}</a>`).join('')}</div>`:''}
      <div class="body-heading">Nguồn gốc</div><ul class="source-links">${links.map(l=>`<li><div class="source-link-name">${esc(l.source_name)} · ${esc(l.category||'')}</div>${l.source_url?`<a class="source-link-url" href="${esc(l.source_url)}" target="_blank" rel="noopener noreferrer">${esc(l.source_url)}</a>`:'<span class="muted">Liên kết không hợp lệ</span>'}${l.last_detail_status?`<div class="muted" style="margin:5px 0 0">Trích xuất lần cuối: ${esc(l.last_detail_status)}${l.last_detail_chars?` · ${l.last_detail_chars} ký tự`:''}</div>`:''}</li>`).join('')}</ul>
      ${quality.length?`<div class="quality-note">Cần lưu ý: ${quality.map(esc).join(' · ')}. Thông tin nguồn gốc được giữ để bạn đối chiếu với bài chính thức.</div>`:''}
    </div>`;
    $('#toggle-read').addEventListener('click',()=>updateAction(a.id,'read',{read:!a.read_at}));
    $('#toggle-favorite').addEventListener('click',()=>updateAction(a.id,'favorite',{favorite:!a.is_favorite}));
  }
  async function loadDetail(id, markRead=true) {
    state.selectedId=id;
    document.querySelectorAll('.article-card').forEach(el=>el.classList.toggle('selected',Number(el.dataset.id)===id));
    try {
      const a=await api('/api/articles/'+id);
      renderDetail(a);
      if(markRead && !a.read_at) await updateAction(id,'read',{read:true},true);
    } catch(err) { toast('Không mở được bài: '+err.message); }
  }
  async function updateAction(id, action, payload, silent=false) {
    try {
      await api(`/api/articles/${id}/${action}`,{method:'POST',body:JSON.stringify(payload)});
      if(!silent)toast(action==='read'?(payload.read?'Đã đánh dấu đã đọc':'Đã đánh dấu chưa đọc'):(payload.favorite?'Đã lưu thông báo':'Đã bỏ lưu thông báo'));
      await loadStats(); await loadList();
      if(state.selectedId===id) await loadDetail(id,false);
    } catch(err){toast('Không lưu được: '+err.message);}
  }
  function syncNav() {
    document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.mode===state.mode));
    document.querySelectorAll('.source-shortcut').forEach(el=>el.classList.toggle('active',el.dataset.source===state.source));
  }
  function bindEvents(){
    document.querySelectorAll('.nav-item').forEach(el=>el.addEventListener('click',()=>{state.mode=el.dataset.mode;state.page=1;syncNav();loadList();}));
    $('#source-filter').addEventListener('change',e=>{state.source=e.target.value;state.page=1;syncNav();loadList();});
    $('#sort-category').addEventListener('change',e=>{state.category=e.target.value;state.page=1;loadList();});
    $('#search-input').addEventListener('input',e=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{state.q=e.target.value.trim();state.page=1;loadList();},240);});
    $('#feed-list').addEventListener('click',e=>{const card=e.target.closest('.article-card');if(card)loadDetail(Number(card.dataset.id));});
    $('#feed-list').addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('article-card')){e.preventDefault();loadDetail(Number(e.target.dataset.id));}});
    $('#source-list').addEventListener('click',e=>{const btn=e.target.closest('[data-source]');if(!btn)return;state.source=state.source===btn.dataset.source?'':btn.dataset.source;$('#source-filter').value=state.source;state.page=1;syncNav();loadList();});
    $('#prev-page').addEventListener('click',()=>{if(state.page>1){state.page--;loadList();}});
    $('#next-page').addEventListener('click',()=>{if(state.page<state.pages){state.page++;loadList();}});
    $('#refresh-btn').addEventListener('click',async()=>{try{await loadStats();await loadList();toast('Đã tải lại dữ liệu từ CSDL');}catch(e){toast('Không tải lại được: '+e.message);}});
    $('#mark-all-read').addEventListener('click', async()=>{
      const unread = Number(state.stats?.unread || 0);
      if (!unread) { toast('Không còn thông báo chưa đọc'); return; }
      if (!window.confirm(`Đánh dấu tất cả ${unread} thông báo chưa đọc trong CSDL là đã đọc?`)) return;
      try {
        const result = await api('/api/read-all', {method:'POST', body:JSON.stringify({})});
        toast(`Đã đánh dấu ${Number(result.updated || 0).toLocaleString('vi-VN')} thông báo là đã đọc`);
        await loadStats();
        await loadList();
        if (state.selectedId !== null) await loadDetail(state.selectedId, false);
      } catch (err) { toast('Không thể đánh dấu tất cả đã đọc: ' + err.message); }
    });
  }
  async function init(){bindEvents();try{await loadStats();await loadList();}catch(err){setStatus('Không kết nối được CSDL',false);$('#feed-list').innerHTML=`<div class="empty-state">${esc(err.message)}</div>`;}}
  init();
})();
