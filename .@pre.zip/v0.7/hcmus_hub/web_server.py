from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent
DASHBOARD_DIR = ROOT / "dashboard"


def _connect(db_path: Path):
    con = sqlite3.connect(db_path, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def _row_article(row: sqlite3.Row, *, include_body: bool = False) -> dict:
    item = dict(row)
    try:
        item["attachments"] = json.loads(item.pop("attachments_json", "[]") or "[]")
    except (json.JSONDecodeError, TypeError):
        item["attachments"] = []
    if not include_body:
        body = item.pop("content", "") or ""
        item["content_preview"] = body[:260]
    return item


def _article_select_sql() -> str:
    return """SELECT a.*, GROUP_CONCAT(DISTINCT s.name) AS source_names,
        GROUP_CONCAT(DISTINCT ars.source_id) AS source_ids,
        GROUP_CONCAT(DISTINCT ars.source_url) AS source_urls,
        GROUP_CONCAT(DISTINCT ars.category) AS source_categories,
        COUNT(DISTINCT ars.source_id) AS source_count
        FROM articles a JOIN article_sources ars ON ars.article_id=a.id
        JOIN sources s ON s.id=ars.source_id"""


def _api_stats(db: Path) -> dict:
    con = _connect(db)
    try:
        total = con.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
        unread = con.execute("SELECT COUNT(*) FROM articles WHERE read_at IS NULL").fetchone()[0]
        favorites = con.execute("SELECT COUNT(*) FROM articles WHERE is_favorite=1").fetchone()[0]
        needs_review = con.execute("""SELECT COUNT(*) FROM articles WHERE
            (COALESCE(content,'')='' AND COALESCE(summary,'')='') OR published_at IS NULL
            OR published_at_source IN ('legacy_unverified','unknown')
            OR title LIKE '[CHƯA LẤY CHI TIẾT]%' OR title LIKE 'Thong bao %'""").fetchone()[0]
        sources = con.execute("""SELECT s.id,s.name,s.last_checked_at,s.last_success_at,s.last_error,
            COUNT(DISTINCT ars.article_id) AS articles
            FROM sources s LEFT JOIN article_sources ars ON ars.source_id=s.id
            GROUP BY s.id ORDER BY s.name""").fetchall()
        categories = [r[0] for r in con.execute("SELECT DISTINCT category FROM article_sources WHERE COALESCE(category,'')<>'' ORDER BY category COLLATE NOCASE")]
        return {"articles": total, "unread": unread, "favorites": favorites,
                "needs_review": needs_review, "categories": categories, "sources": [dict(r) for r in sources]}
    finally:
        con.close()


def _api_articles(db: Path, params: dict[str, list[str]]) -> dict:
    q = (params.get("q", [""])[0] or "").strip()[:200]
    source = (params.get("source", [""])[0] or "").strip()
    category = (params.get("category", [""])[0] or "").strip()
    mode = (params.get("mode", ["all"])[0] or "all").strip()
    page = max(1, min(int((params.get("page", ["1"])[0] or "1")), 100000))
    limit = max(5, min(int((params.get("limit", ["30"])[0] or "30")), 100))
    where, args = [], []
    if q:
        where.append("(a.title LIKE ? OR a.summary LIKE ? OR a.content LIKE ?)")
        needle = f"%{q}%"
        args.extend([needle, needle, needle])
    if source:
        where.append("EXISTS (SELECT 1 FROM article_sources ax WHERE ax.article_id=a.id AND ax.source_id=?)")
        args.append(source)
    if category:
        where.append("EXISTS (SELECT 1 FROM article_sources ac WHERE ac.article_id=a.id AND ac.category=?)")
        args.append(category)
    if mode == "unread":
        where.append("a.read_at IS NULL")
    elif mode == "favorites":
        where.append("a.is_favorite=1")
    elif mode == "review":
        where.append("((COALESCE(a.content,'')='') AND (COALESCE(a.summary,'')='')) OR a.published_at IS NULL OR a.published_at_source IN ('legacy_unverified','unknown') OR a.title LIKE '[CHƯA LẤY CHI TIẾT]%' OR a.title LIKE 'Thong bao %'")
    where_sql = (" WHERE " + " AND ".join(f"({part})" for part in where)) if where else ""
    con = _connect(db)
    try:
        total = con.execute("SELECT COUNT(*) FROM articles a" + where_sql, args).fetchone()[0]
        sql = _article_select_sql() + where_sql + " GROUP BY a.id ORDER BY CASE WHEN a.published_at IS NULL OR a.published_at_source IN ('legacy_unverified','unknown') THEN 1 ELSE 0 END, a.published_at DESC, a.first_seen_at DESC LIMIT ? OFFSET ?"
        rows = con.execute(sql, [*args, limit, (page - 1) * limit]).fetchall()
        items = [_row_article(row) for row in rows]
        return {"items": items, "total": total, "page": page, "limit": limit,
                "pages": max(1, (total + limit - 1) // limit)}
    finally:
        con.close()


def _api_article_detail(db: Path, article_id: int) -> dict | None:
    con = _connect(db)
    try:
        row = con.execute(_article_select_sql() + " WHERE a.id=? GROUP BY a.id", (article_id,)).fetchone()
        if not row:
            return None
        item = _row_article(row, include_body=True)
        item["sources"] = [dict(r) for r in con.execute("""SELECT s.id AS source_id,s.name AS source_name,
            ars.source_url,ars.category,ars.last_detail_attempt_at,ars.last_detail_status,ars.last_detail_chars,ars.last_detail_error
            FROM article_sources ars JOIN sources s ON s.id=ars.source_id WHERE ars.article_id=? ORDER BY s.name,ars.category""", (article_id,)).fetchall()]
        return item
    finally:
        con.close()


class _HubHandler(BaseHTTPRequestHandler):
    server_version = "HCMUSHub/0.7"

    @property
    def db_path(self) -> Path:
        return self.server.db_path  # type: ignore[attr-defined]

    def log_message(self, format, *args):
        # Keep terminal logs useful without leaking query contents.
        print(f"[WEB] {self.address_string()} {self.command} {self.path.split('?')[0]}")

    def _send(self, body: bytes, status: int = 200, content_type: str = "application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status: int = 200):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"), status)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)
        try:
            if path == "/api/stats":
                self._json(_api_stats(self.db_path)); return
            if path == "/api/articles":
                self._json(_api_articles(self.db_path, params)); return
            if path.startswith("/api/articles/"):
                try: article_id = int(path.rsplit("/", 1)[-1])
                except ValueError: self._json({"error": "ID bài viết không hợp lệ"}, 400); return
                item = _api_article_detail(self.db_path, article_id)
                self._json(item if item else {"error": "Không tìm thấy bài viết"}, 200 if item else 404); return
            if path == "/health":
                self._json({"status": "ok", "database_exists": self.db_path.exists()}); return
            rel = "index.html" if path in {"/", "/index.html"} else path.lstrip("/")
            target = (DASHBOARD_DIR / rel).resolve()
            if DASHBOARD_DIR.resolve() not in target.parents and target != (DASHBOARD_DIR / "index.html").resolve():
                self._json({"error": "Không tìm thấy"}, 404); return
            if not target.is_file():
                self._json({"error": "Không tìm thấy"}, 404); return
            content_type = "text/html; charset=utf-8" if target.suffix == ".html" else "text/javascript; charset=utf-8" if target.suffix == ".js" else "text/css; charset=utf-8" if target.suffix == ".css" else "application/octet-stream"
            self._send(target.read_bytes(), 200, content_type)
        except Exception as exc:
            self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

    def do_POST(self):
        parsed = urlparse(self.path)
        match = re_match_action(parsed.path)
        if not match:
            self._json({"error": "Endpoint không hợp lệ"}, 404); return
        article_id, action = match
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 10000)
            payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
            con = _connect(self.db_path)
            try:
                if action == "read":
                    value = bool(payload.get("read", True))
                    read_at = datetime.now().astimezone().isoformat(timespec="seconds") if value else None
                    cur = con.execute("UPDATE articles SET read_at=? WHERE id=?", (read_at, article_id))
                else:
                    value = bool(payload.get("favorite", True))
                    cur = con.execute("UPDATE articles SET is_favorite=? WHERE id=?", (int(value), article_id))
                con.commit()
                if not cur.rowcount:
                    self._json({"error": "Không tìm thấy bài viết"}, 404); return
                self._json({"id": article_id, "action": action, "value": value})
            finally:
                con.close()
        except (ValueError, json.JSONDecodeError) as exc:
            self._json({"error": f"Yêu cầu không hợp lệ: {exc}"}, 400)
        except Exception as exc:
            self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)


def re_match_action(path: str):
    import re
    match = re.fullmatch(r"/api/articles/(\d+)/(read|favorite)", path)
    return (int(match.group(1)), match.group(2)) if match else None


def serve_dashboard(db_path: str | Path, host: str = "127.0.0.1", port: int = 8787):
    database = Path(db_path).expanduser().resolve()
    if not database.exists():
        raise FileNotFoundError(f"Không tìm thấy CSDL: {database}. Hãy chạy sync hoặc run-all trước.")
    # Apply additive SQLite schema migrations before serving API queries.
    from .store import Store
    migrated_store = Store(database)
    migrated_store.close()
    # Bind to loopback by default to keep student data local. Explicit public bind is not supported by default.
    server = ThreadingHTTPServer((host, port), _HubHandler)
    server.db_path = database  # type: ignore[attr-defined]
    print(f"HCMUS Hub dashboard: http://{host}:{port}")
    print(f"CSDL: {database}")
    print("Nhấn Ctrl+C để dừng. Mặc định chỉ máy này truy cập được.")
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nĐã dừng HCMUS Hub dashboard.")
    finally:
        server.server_close()
