"""Personal HCMUS information hub - source collector, quality tools, and local dashboard."""
__version__ = "0.7.0"
