"""Personal HCMUS information hub - source collector and one-pass maintenance."""
__version__ = "0.6.0"
