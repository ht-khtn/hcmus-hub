from __future__ import annotations

import argparse
import asyncio
import json
from datetime import datetime
from pathlib import Path

from .config import load_config
from .discovery import audit_source
from .fetcher import PoliteFetcher
from .store import Store
from .sync import sync_source

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = ROOT / "config" / "sources.json"
DEFAULT_DB = ROOT / "data" / "hcmus_hub.sqlite3"


def _load_args_config(path: str):
    config_path = Path(path).expanduser().resolve()
    config, sources = load_config(config_path)
    return config, sources, config_path


def _create_fetcher(config, *, force_delay: float | None = None) -> PoliteFetcher:
    return PoliteFetcher(
        user_agent=config.get("user_agent", "HCMUSHub/0.1"),
        timeout=float(config.get("request_timeout_seconds", 20)),
        delay=float(config.get("delay_between_requests_seconds", 0.8) if force_delay is None else force_delay),
        max_bytes=int(config.get("max_response_bytes", 5_000_000)),
        respect_robots=True,
    )


async def _run_audit(args):
    config, sources, config_path = _load_args_config(args.config)
    target_dir = Path(args.output).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    selected = [s for s in sources if (not args.source or s.id in args.source)]
    reports = []
    async with _create_fetcher(config, force_delay=args.delay) as fetcher:
        # Keep audit gentle: unique origins are cached for robots checks; endpoints are requested sequentially.
        for source in selected:
            print(f"[AUDIT] {source.id}: {source.name}")
            reports.append(await audit_source(source, fetcher))
        shared_warnings = list(fetcher.warnings)
    generated_at = datetime.now().astimezone().isoformat(timespec="seconds")
    payload = {"generated_at": generated_at, "config": str(config_path), "sources": reports, "warnings": shared_warnings}
    json_path = target_dir / "source-audit.json"
    md_path = target_dir / "source-audit.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md = ["# Báo cáo audit nguồn HCMUS Hub", "", f"- Chạy lúc: `{generated_at}`", f"- File cấu hình: `{config_path}`", ""]
    for item in reports:
        md += [f"## {item['source_name']} (`{item['source_id']}`)", "", f"- Base URL: {item['base_url']}", f"- Hướng đề xuất: **{item['recommendation']}**", "", "| Loại probe | HTTP | Phân loại | URL | Ghi chú |", "|---|---:|---|---|---|"]
        for row in item["results"]:
            status = row.get("status") if row.get("status") is not None else "—"
            url = row.get("url", "").replace("|", "%7C")
            note = row.get("note", "").replace("|", "\\|").replace("\n", " ")
            md.append(f"| {row.get('label','')} | {status} | {row.get('classification','')} | {url} | {note} |")
        if item.get("warnings"):
            md += ["", "Cảnh báo: " + "; ".join(item["warnings"])]
        md.append("")
    if shared_warnings:
        md += ["## Cảnh báo chung", "", *[f"- {warning}" for warning in shared_warnings], ""]
    md_path.write_text("\n".join(md), encoding="utf-8")
    print(f"Đã ghi: {json_path}")
    print(f"Đã ghi: {md_path}")
    for report in reports:
        print(f"  {report['source_id']}: {report['recommendation']} ({len(report['results'])} probes)")


async def _run_sync(args):
    config, sources, _ = _load_args_config(args.config)
    selected = [s for s in sources if s.enabled and (not args.source or s.id in args.source)]
    if args.include_reference:
        selected = [s for s in sources if (not args.source or s.id in args.source)]
    if not selected:
        print("Không có nguồn phù hợp. Kiểm tra config/sources.json và tuỳ chọn --source.")
        return
    db_path = Path(args.db).expanduser().resolve()
    store = Store(db_path)
    try:
        async with _create_fetcher(config, force_delay=args.delay) as fetcher:
            for source in selected:
                print(f"[SYNC] {source.id}: {source.name}")
                report = await sync_source(source, fetcher, store,
                                           max_details=args.max_details,
                                           max_items_per_listing=args.max_items_per_listing)
                print(json.dumps(report, ensure_ascii=False, indent=2))
            if fetcher.warnings:
                print("CẢNH BÁO FETCHER:")
                for warning in fetcher.warnings:
                    print("- " + warning)
        print(f"CSDL: {db_path}")
        print(f"Tổng: {json.dumps(store.counts(), ensure_ascii=False)}")
    finally:
        store.close()


def _run_list(args):
    store = Store(Path(args.db).expanduser().resolve())
    try:
        rows = store.list_articles(limit=args.limit, unread_only=args.unread)
        if not rows:
            print("Chưa có thông báo. Chạy lệnh sync trước.")
            return
        for i, row in enumerate(rows, start=1):
            date_text = row["published_at"] or "chưa rõ ngày"
            sources = row["source_names"] or "nguồn không rõ"
            categories = row.get("source_categories") or row["category"]
            print(f"{i:02d}. [{categories}] {row['title']}\n    Ngày: {date_text} | Nguồn: {sources}\n    URL: {row['source_urls']}\n")
    finally:
        store.close()


def _run_export(args):
    store = Store(Path(args.db).expanduser().resolve())
    try:
        data = store.export_articles()
        target = Path(args.output).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Đã xuất {len(data)} bài: {target}")
    finally:
        store.close()


def build_parser():
    parser = argparse.ArgumentParser(prog="hcmus-hub", description="Bộ thu thập thông báo HCMUS Hub - v0.1")
    sub = parser.add_subparsers(dest="command", required=True)
    audit = sub.add_parser("audit", help="Kiểm tra robots/sitemap/feed/API và trang danh mục trực tiếp")
    audit.add_argument("--config", default=str(DEFAULT_CONFIG))
    audit.add_argument("--output", default=str(ROOT / "data" / "audit"))
    audit.add_argument("--source", action="append", help="ID nguồn; lặp lại để chọn nhiều nguồn. Mặc định tất cả.")
    audit.add_argument("--delay", type=float, default=None, help="Giây tối thiểu giữa các yêu cầu tới cùng host.")
    audit.set_defaults(func=lambda args: asyncio.run(_run_audit(args)))

    sync = sub.add_parser("sync", help="Đồng bộ thông báo vào SQLite")
    sync.add_argument("--config", default=str(DEFAULT_CONFIG))
    sync.add_argument("--db", default=str(DEFAULT_DB))
    sync.add_argument("--source", action="append", help="ID nguồn; mặc định các nguồn enabled.")
    sync.add_argument("--include-reference", action="store_true", help="Cho phép đồng bộ nguồn kind=reference đang disabled.")
    sync.add_argument("--max-details", type=int, default=None, help="Giới hạn số bài chi tiết tải cho mỗi nguồn.")
    sync.add_argument("--max-items-per-listing", type=int, default=30)
    sync.add_argument("--delay", type=float, default=None)
    sync.set_defaults(func=lambda args: asyncio.run(_run_sync(args)))

    listing = sub.add_parser("list", help="Xem thông báo đã lưu")
    listing.add_argument("--db", default=str(DEFAULT_DB))
    listing.add_argument("--limit", type=int, default=30)
    listing.add_argument("--unread", action="store_true")
    listing.set_defaults(func=_run_list)

    export = sub.add_parser("export", help="Xuất toàn bộ dữ liệu ra JSON")
    export.add_argument("--db", default=str(DEFAULT_DB))
    export.add_argument("--output", default=str(ROOT / "data" / "export.json"))
    export.set_defaults(func=_run_export)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
