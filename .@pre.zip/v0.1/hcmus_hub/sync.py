from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit, urljoin
from xml.etree import ElementTree as ET

from bs4 import BeautifulSoup

from .fetcher import FetchError, PoliteFetcher
from .models import Article, ListingConfig, SourceConfig
from .parsers import parse_detail_html, parse_feed, parse_listing_html
from .store import Store
from .textutils import normalize_url


def next_page_url(html: str, current_url: str, page_number: int) -> str | None:
    """Find an explicit next-page link. Avoid guessing URLs on unknown CMSs."""
    soup = BeautifulSoup(html, "html.parser")
    next_node = soup.find("a", rel=lambda value: value and ("next" in value if isinstance(value, list) else "next" in str(value).lower()))
    if next_node and next_node.get("href"):
        return normalize_url(urljoin(current_url, str(next_node["href"])))
    for anchor in soup.find_all("a", href=True):
        label = " ".join(anchor.get("rel", [])) if isinstance(anchor.get("rel"), list) else str(anchor.get("rel", ""))
        text = (anchor.get_text(" ", strip=True) + " " + label).strip().lower()
        if re.search(r"^(next|older|sau|tiếp|trang sau|›|»|→)$", text):
            return normalize_url(urljoin(current_url, str(anchor["href"])))
    # A few known paging conventions. For FIT's custom listing, page 1 is the base URL;
    # older pages are query parameters p=2, p=3, ... .
    parsed = urlsplit(current_url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if "p" in query and query["p"].isdigit():
        query["p"] = str(int(query["p"]) + 1)
        return normalize_url(urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), "")))
    if "/beta/tin-tuc/c/" in parsed.path or "/tin-tuc/c/" in parsed.path:
        query["p"] = str(max(2, page_number + 1))
        return normalize_url(urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), "")))
    # WordPress convention, only for category/archive paths known to be WordPress-like.
    if "/danh-muc/" in parsed.path:
        path = parsed.path.rstrip("/") + f"/page/{page_number + 1}/"
        return normalize_url(urlunsplit((parsed.scheme, parsed.netloc, path, parsed.query, "")))
    return None


def _looks_like_feed(result) -> bool:
    body = result.text.lstrip()
    if "xml" not in result.content_type and not body.startswith("<?xml") and not body.startswith("<rss") and not body.startswith("<feed"):
        return False
    try:
        root = ET.fromstring(result.text)
        return root.tag.lower().split("}")[-1] in {"rss", "feed", "rdf"}
    except ET.ParseError:
        return False


async def sync_source(source: SourceConfig, fetcher: PoliteFetcher, store: Store,
                      max_details: int | None = None, max_items_per_listing: int = 30) -> dict:
    store.register_source(source)
    store.source_check_started(source.id)
    seen_urls: set[str] = set()
    discovered: list[Article] = []
    listing_errors: list[str] = []
    successful_listings = 0
    try:
        for listing in source.listings:
            url = listing.url
            visited_pages: set[str] = set()
            for page_no in range(1, max(1, source.max_pages) + 1):
                if url in visited_pages:
                    break
                visited_pages.add(url)
                try:
                    response = await fetcher.get(url)
                except FetchError as exc:
                    listing_errors.append(f"{url}: {exc}")
                    break
                successful_listings += 1
                if _looks_like_feed(response):
                    page_articles = parse_feed(response.text, response.url, source.id, source.name, listing.category)
                else:
                    page_articles = parse_listing_html(
                        response.text, response.url, source.id, source.name,
                        listing.category, listing.selectors,
                        link_patterns=["/beta/tin-tuc/d/", "/tin-tuc/d/", "/news/"],
                    )
                for article in page_articles:
                    if article.source_url not in seen_urls:
                        discovered.append(article)
                        seen_urls.add(article.source_url)
                    if len([a for a in discovered if a.category == listing.category]) >= max_items_per_listing:
                        break
                if page_no >= source.max_pages:
                    break
                more = next_page_url(response.text, response.url, page_no)
                if not more or more in visited_pages:
                    break
                url = more
        # Persist list-level metadata first. This means a detail failure still keeps the notification title/URL.
        outcomes: dict[str, int] = {"new": 0, "updated_content": 0, "linked_duplicate": 0, "unchanged": 0}
        for article in discovered:
            outcomes[store.upsert_article(article)] += 1

        details_limit = source.max_details_per_sync if max_details is None else max_details
        detail_count = 0
        detail_errors: list[str] = []
        # Refresh a small number of newest detail pages on each run. This is deliberately capped;
        # it can detect deadline/content edits without redownloading the full historical archive.
        details_attempted = 0
        source_host = urlsplit(source.base_url).netloc.lower()
        for article in discovered:
            if details_attempted >= max(0, details_limit):
                break
            # Do not crawl arbitrary third-party pages linked from a feed/listing.
            if urlsplit(article.source_url).netloc.lower() != source_host:
                continue
            details_attempted += 1
            try:
                detail_response = await fetcher.get(article.source_url)
                enriched = parse_detail_html(detail_response.text, article)
                outcomes[store.upsert_article(enriched)] += 1
                detail_count += 1
            except FetchError as exc:
                detail_errors.append(f"{article.source_url}: {exc}")

        all_errors = listing_errors + detail_errors
        if successful_listings and not discovered:
            all_errors.append("Đọc được trang danh mục nhưng không trích xuất được bài nào; cần kiểm tra selector/JavaScript và báo cáo audit.")
        store.source_check_finished(source.id, "; ".join(all_errors[:3]) if all_errors else None)
        return {
            "source_id": source.id,
            "source_name": source.name,
            "listings_succeeded": successful_listings,
            "articles_discovered": len(discovered),
            "details_fetched": detail_count,
            "outcomes": outcomes,
            "errors": all_errors,
            "warnings": list(fetcher.warnings),
        }
    except Exception as exc:
        store.source_check_finished(source.id, str(exc))
        raise
