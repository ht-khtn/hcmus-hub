"""Personal HCMUS information hub - first-stage collector."""
__version__ = "0.1.0"
