from __future__ import annotations

import re
from datetime import datetime
from email.utils import parsedate_to_datetime
from urllib.parse import urljoin, urlparse
from xml.etree import ElementTree as ET

from bs4 import BeautifulSoup, Tag

from .models import Article
from .textutils import clean_text, content_digest, normalize_url, parse_date

ATTACHMENT_EXTENSIONS = (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".zip", ".rar", ".png", ".jpg", ".jpeg")
NAV_WORDS = {"trang chủ", "home", "liên hệ", "contact", "đăng nhập", "login", "tìm kiếm", "search", "xem thêm", "read more", "1", "2", "3", "4", "5", "→", "←"}
EXCLUDED_PATH_BITS = ("/wp-login", "/wp-admin", "/tag/", "/author/", "/login", "/lien-he", "/contact", "/search", "/page/", "/danh-muc/")


def _is_valid_title(title: str) -> bool:
    folded = clean_text(title).casefold()
    return len(folded) >= 9 and folded not in NAV_WORDS and len(folded.split()) >= 2


def _article_link_is_plausible(href: str, listing_url: str, allowed_patterns: list[str] | None = None) -> bool:
    full = normalize_url(urljoin(listing_url, href))
    candidate = urlparse(full)
    listing = urlparse(listing_url)
    if candidate.scheme not in {"http", "https"} or candidate.netloc != listing.netloc:
        return False
    if candidate.path.rstrip("/") == listing.path.rstrip("/"):
        return False
    path_lower = candidate.path.lower()
    if any(bit in path_lower for bit in EXCLUDED_PATH_BITS):
        # Categories can link to articles, but not article-like links themselves.
        if not any(pattern in path_lower for pattern in (allowed_patterns or [])):
            return False
    if any(path_lower.endswith(ext) for ext in ATTACHMENT_EXTENSIONS):
        return False
    if allowed_patterns and any(pattern in path_lower for pattern in allowed_patterns):
        return True
    # General article candidates should not be very short navigation paths.
    segments = [segment for segment in candidate.path.split("/") if segment]
    if len(segments) >= 2:
        return True
    if len(segments) == 1 and len(segments[0]) >= 18 and "-" in segments[0]:
        return True
    return False


def _anchor_context_text(anchor: Tag) -> str:
    parent = anchor.parent
    for _ in range(4):
        if parent is None:
            break
        if parent.name in {"article", "li", "div", "section"}:
            text = clean_text(parent.get_text(" ", strip=True))
            if len(text) >= len(clean_text(anchor.get_text(" ", strip=True))) + 4:
                return text[:1200]
        parent = parent.parent
    return clean_text(anchor.get_text(" ", strip=True))


def _date_from_context(text: str) -> str | None:
    # Prefer a full date; don't mistake an event date embedded in titles as publish date.
    patterns = [
        r"\b\d{1,2}[/.\-]\d{1,2}[/.\-]\d{4}\b",
        r"\b\d{4}-\d{1,2}-\d{1,2}\b",
        r"\b\d{1,2}\s+(?:tháng\s+\d{1,2}|th\s*\d{1,2})(?:\s+\d{4})?\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            parsed = parse_date(match.group(0), reference_year=datetime.now().year)
            if parsed:
                return parsed
    return None


def parse_listing_html(html: str, listing_url: str, source_id: str, source_name: str,
                       category: str, selectors: list[str] | None = None,
                       link_patterns: list[str] | None = None) -> list[Article]:
    soup = BeautifulSoup(html, "html.parser")
    selected: list[Tag] = []
    used_selector = False
    for selector in selectors or []:
        try:
            matches = soup.select(selector)
        except Exception:
            continue
        if matches:
            used_selector = True
            selected.extend(a for a in matches if isinstance(a, Tag) and a.name == "a")
    if not selected:
        # Generic fallbacks; prefer semantic article-title nodes over arbitrary navigation links.
        preferred_selectors = [
            "article h1 a", "article h2 a", "article h3 a", "article h4 a",
            ".entry-title a", ".post-title a", ".news-title a", ".item-title a",
            ".news-item a[href]", ".post a[href]", ".blog-item a[href]",
        ]
        for selector in preferred_selectors:
            selected.extend(a for a in soup.select(selector) if isinstance(a, Tag) and a.name == "a")
        if not selected:
            selected = list(soup.find_all("a", href=True))

    output: list[Article] = []
    seen_urls: set[str] = set()
    for anchor in selected:
        href = str(anchor.get("href", "")).strip()
        title = clean_text(anchor.get_text(" ", strip=True) or anchor.get("title", ""))
        if not href or not _is_valid_title(title):
            continue
        absolute = normalize_url(urljoin(listing_url, href))
        if absolute in seen_urls or not _article_link_is_plausible(absolute, listing_url, link_patterns):
            continue
        seen_urls.add(absolute)
        context = _anchor_context_text(anchor)
        # Remove title from context to form a concise snippet where possible.
        summary = context.replace(title, "", 1).strip(" :-|·")
        if len(summary) > 500:
            summary = summary[:497].rstrip() + "..."
        published = _date_from_context(context)
        article = Article(
            title=title, source_id=source_id, source_name=source_name,
            category=category, source_url=absolute, published_at=published,
            summary=summary, content="", attachments=[],
        )
        article.content_hash = content_digest(article.title, article.summary, article.content)
        output.append(article)
    return output


def parse_detail_html(html: str, article: Article) -> Article:
    soup = BeautifulSoup(html, "html.parser")
    title_node = soup.find("h1") or soup.find("meta", property="og:title")
    if title_node:
        title = title_node.get("content") if title_node.name == "meta" else title_node.get_text(" ", strip=True)
        title = clean_text(title)
        if len(title) >= 5:
            article.title = title

    # Parse published date from datetime attributes first, then visible text near the header.
    time_node = soup.find("time", datetime=True)
    if time_node:
        article.published_at = parse_date(str(time_node.get("datetime", ""))) or article.published_at
    if not article.published_at:
        published_meta = soup.find("meta", attrs={"property": re.compile(r"article:published_time|og:published_time", re.I)})
        if published_meta:
            article.published_at = parse_date(str(published_meta.get("content", ""))) or article.published_at

    content_node = None
    for selector in ["article .entry-content", ".entry-content", ".article-content", ".news-content", ".post-content", "main article", "article", "main"]:
        node = soup.select_one(selector)
        if node and len(clean_text(node.get_text(" ", strip=True))) > 120:
            content_node = node
            break
    if content_node is None:
        # Avoid replacing content with a full page if no likely content container exists.
        content_node = soup.body or soup

    for unwanted in content_node.select("script, style, nav, footer, header, aside, form, .share, .social, .related, .breadcrumb"):
        unwanted.decompose()
    content = "\n".join(clean_text(part) for part in content_node.stripped_strings)
    content = re.sub(r"\n{3,}", "\n\n", content).strip()
    if len(content) > 30_000:
        content = content[:30_000].rstrip() + "\n[Đã cắt nội dung ở 30.000 ký tự trong bản thu thập.]"
    if len(content) > len(article.content):
        article.content = content

    attachments: list[str] = []
    for anchor in content_node.find_all("a", href=True):
        href = normalize_url(urljoin(article.source_url, str(anchor.get("href", ""))))
        if urlparse(href).path.lower().endswith(ATTACHMENT_EXTENSIONS):
            attachments.append(href)
    article.attachments = sorted(set(attachments))
    article.content_hash = content_digest(article.title, article.summary, article.content, article.attachments)
    return article


def parse_feed(xml_text: str, listing_url: str, source_id: str, source_name: str, category: str) -> list[Article]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    ns = {"atom": "http://www.w3.org/2005/Atom", "content": "http://purl.org/rss/1.0/modules/content/"}
    items = root.findall(".//item") or root.findall(".//atom:entry", ns)
    output: list[Article] = []
    for item in items:
        title_node = item.find("title")
        if title_node is None:
            title_node = item.find("atom:title", ns)
        title = clean_text("".join(title_node.itertext()) if title_node is not None else "")
        if not _is_valid_title(title):
            continue
        link_node = item.find("link")
        if link_node is not None and link_node.text:
            url = urljoin(listing_url, link_node.text.strip())
        else:
            atom_link = item.find("atom:link", ns)
            url = urljoin(listing_url, atom_link.attrib.get("href", "")) if atom_link is not None else ""
        if not url:
            continue
        date_node = item.find("pubDate")
        if date_node is None:
            date_node = item.find("dc:date", {"dc": "http://purl.org/dc/elements/1.1/"})
        if date_node is None:
            date_node = item.find("atom:published", ns)
        if date_node is None:
            date_node = item.find("atom:updated", ns)
        published = None
        if date_node is not None:
            date_text = clean_text("".join(date_node.itertext()))
            published = parse_date(date_text)
            if not published:
                try:
                    published = parsedate_to_datetime(date_text).date().isoformat()
                except (TypeError, ValueError, OverflowError):
                    pass
        desc_node = item.find("description")
        if desc_node is None:
            desc_node = item.find("atom:summary", ns)
        summary = clean_text("".join(desc_node.itertext()) if desc_node is not None else "")
        article = Article(title=title, source_id=source_id, source_name=source_name,
                          category=category, source_url=normalize_url(url), published_at=published,
                          summary=summary[:1000])
        article.content_hash = content_digest(article.title, article.summary, "")
        output.append(article)
    return output
