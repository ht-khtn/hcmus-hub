# Trạng thái bàn giao — 15/10/2026

## Đã làm

- Tạo `config/sources.json` với 9 nguồn: FIT, CTSV, HCMUS, Phòng Đào tạo, Tuyển sinh, SVNCKH, Đoàn–Hội, Sổ tay Sinh viên và cổng nghiên cứu.
- Bật mặc định 7 nguồn tin tức/thông báo; tắt mặc định Sổ tay và Research vì đây là nguồn tra cứu/reference cần cách xử lý khác.
- Thêm lệnh audit để kiểm tra robots.txt, sitemap, feed RSS/Atom, endpoint WordPress REST phổ biến và URL danh mục; báo cáo ra Markdown + JSON.
- Thêm bộ lấy HTTP có timeout, retry giới hạn, giới hạn kích thước phản hồi, độ trễ theo host và kiểm tra robots.txt.
- Thêm parser RSS/Atom và HTML, trích xuất title/date/snippet/body/URL tệp đính kèm, phân trang cho đường dẫn FIT đã quan sát.
- Thêm SQLite với nguồn gốc nhiều nguồn, khử trùng lặp heuristic, dấu vết nội dung và lưu revision khi bài đã có thân nội dung thay đổi.
- Thêm CLI `audit`, `sync`, `list`, `export` và hướng dẫn chạy trên Kali/Ubuntu/Windows.
- Có 15 kiểm thử tự động cho parser, feed, phân trang, cơ sở dữ liệu, khử trùng lặp và đồng bộ giả lập.

## Kết quả kiểm thử trong môi trường phát triển

- `python -m unittest discover -v`: **15 tests passed**.
- `python -m compileall -q hcmus_hub tests`: thành công.
- `python -m hcmus_hub --help`: lệnh CLI khởi động được.
- Đã kiểm tra JSON cấu hình và xác nhận có 9 nguồn, trong đó 7 nguồn bật mặc định.

## Chưa thể tuyên bố hoàn tất

- Chưa chạy được HTTP GET trực tiếp tới website HCMUS từ môi trường phát triển của trợ lý do lỗi phân giải DNS ở container. Các cấu trúc trang công khai được khảo sát qua nguồn web/indexed pages; endpoint RSS/API/robots/sitemap vẫn cần `audit` trực tiếp từ máy của người dùng.
- Các selector HCMUS/CTSV/Tuyển sinh/Đoàn–Hội cần tinh chỉnh sau khi xem kết quả chạy thật; cấu hình hiện tại là bộ khởi đầu, không bảo đảm mọi bài đều trích xuất chuẩn.
- Chưa dựng giao diện web (đó là giai đoạn C), chưa chạy scheduler 08:00, chưa triển khai hosting, chưa kết nối Portal Sinh viên/UStudy.

## Tiêu chí trước khi tin dùng dữ liệu

Không coi bộ thu thập là ổn định cho đến khi audit từ máy thật xác nhận endpoint, sync ra các bài có tiêu đề/ngày/link đúng, chạy lần hai không tăng số bài trùng, và một thông báo có sửa nội dung tạo revision hợp lý.
