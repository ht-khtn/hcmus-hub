import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from hcmus_hub.models import ListingConfig, SourceConfig
from hcmus_hub.store import Store
from hcmus_hub.sync import sync_source

ROOT = Path(__file__).resolve().parent


class FakeFetcher:
    warnings = []

    async def get(self, url, **kwargs):
        if "/beta/tin-tuc/c/" in url:
            body = (ROOT / "fixtures" / "fit_listing.html").read_text(encoding="utf-8")
        elif url.endswith("dang-ky-tham-quan-bosch"):
            body = (ROOT / "fixtures" / "fit_detail.html").read_text(encoding="utf-8")
        else:
            body = (ROOT / "fixtures" / "fit_detail.html").read_text(encoding="utf-8")
        return SimpleNamespace(url=url, status_code=200, content_type="text/html; charset=utf-8", text=body, headers={})


class SyncTests(unittest.TestCase):
    def test_sync_listing_detail_and_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "hcmus.sqlite3")
            source = SourceConfig(
                id="fit", name="FIT", owner="FIT", base_url="https://www.fit.hcmus.edu.vn/",
                kind="announcements", enabled=True,
                listings=[ListingConfig(
                    "https://www.fit.hcmus.edu.vn/beta/tin-tuc/c/thong-bao-chung",
                    "Thông báo chung", ["a[href*='/beta/tin-tuc/d/']"]
                )],
                max_pages=1, max_details_per_sync=1,
            )
            try:
                report = asyncio.run(sync_source(source, FakeFetcher(), store, max_details=1))
                self.assertEqual(report["articles_discovered"], 2)
                self.assertEqual(report["details_fetched"], 1)
                self.assertEqual(store.counts()["articles"], 2)
                rows = store.list_articles(limit=10)
                detailed = next(row for row in rows if "Bosch" in row["title"])
                self.assertIn("Thời hạn đăng ký", detailed["content"])
                self.assertEqual(detailed["source_count"], 1)
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()
