"""Personal HCMUS information hub - first-stage collector."""
__version__ = "0.4.0"
